<?php

require APPPATH . '/third_party/RestController.php';
require APPPATH . '/third_party/Format.php';

use chriskacerguis\RestServer\RestController;

class Receipt extends RestController
{


    protected $receipt_type = [ 'BANK', 'OFFICE', 'ONLINE' ];
    protected $associations = [ 'DTBA', 'BTLA' ];

    protected $methods = [
        'types_get' => ['level' => 1, 'limit' => 1000],
        'list_get' => ['level' => 1, 'limit' => 1000],
    ];

    public function types_get()
    {
        $this->response([
            'status' => TRUE,
            'data' => $this->receipt_type
        ], RestController::HTTP_OK);

    }

    public function list_get()
    {
        $this->response([
            'status' => TRUE,
            'data' => $this->receipt_type
        ], RestController::HTTP_OK);

    }

}