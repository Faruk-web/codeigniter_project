<?php


//namespace bank;

require APPPATH . '/third_party/RestController.php';
require APPPATH . '/third_party/Format.php';

use chriskacerguis\RestServer\RestController;

class Transaction extends RestController
{
    public function __construct($config = 'rest')
    {

        parent::__construct();
        $this->get_local_config($config);
        // TODO populate $associations
        // TODO populate $receipt_type

    }

    protected $receipt_type = ['BANK', 'OFFICE', 'ONLINE'];
    protected $associations = ['DTBA', 'BTLA'];

    protected $current_bank = 'SIBL';
    protected $table = 'bank_transaction';

    protected $methods = [
        'index_get' => ['level' => 1, 'limit' => 1000],
        'receipts_get' => ['level' => 1, 'limit' => 1000],
        'deposit_get' => ['level' => 1, 'limit' => 1000],
        'deposit_post' => ['level' => 1, 'limit' => 1000],
        'deposit_put' => ['level' => 1, 'limit' => 1000],
        'deposit_delete' => ['level' => 1, 'limit' => 1000],
    ];

    public function index_get($trxn_id)
    {
        $trxn = $this->db
            ->where('transaction_id', $trxn_id)
            ->get($this->table)
            ->row();
        // TODO send only relevant row data into response
        if ($trxn) {
            $this->response([
                'status' => TRUE,
                'membership' => $trxn
            ], RestController::HTTP_OK);         // CREATED (200) being the HTTP response code
        } else {
            $this->response([
                'status' => FALSE,
                'message' => 'Could not find any transaction with ' . $trxn_id
            ], RestController::HTTP_NOT_FOUND);         // INTERNAL_SERVER_ERROR (500) being the HTTP response code
        }
    }

    public function list_get()
    {
        $order = $this->input->get_post('order') ? $this->input->get_post('order') : 'ASC';
        $column = $this->input->get_post('column') ? $this->input->get_post('column') : 'id';
        $offset = $this->input->get_post('offset') ? $this->input->get_post('offset') : 0;
        $limit = $this->input->get_post('limit') ? $this->input->get_post('limit') : 10;
        $query = $this->input->get_post('q') ? $this->input->get_post('q') : null;
        $fromDate = $this->input->get_post('fromDate') ? $this->input->get_post('fromDate') : null;
        $toDate = $this->input->get_post('toDate') ? $this->input->get_post('toDate') : null;

//        if(){
//
//        }
//        if($fromDate) {
//            $fromDate = date();
//        }
//
//        if($toDate) {
//            $fromDate = date();
//        }

        // list all with limit and order

        $qStr = ($query != null ) ?  "member_code like '%".$query
            ."%' OR member_phone  like '%".$query
            ."%' OR receipt_number  like '%".$query
            ."%' OR transaction_id like '%".$query
            ."%' OR branch_code like '%".$query."%'" : " id > 0";

        $trxn = $this->db
            ->order_by($column, $order)
            ->limit($limit, $offset)
            ->where('is_deleted', 1)
            ->where($qStr)
            ->get($this->table)
            ->result();

        // TODO send only relevant row data into response
        if ($trxn) {
            $this->response([
                'status' => TRUE,
                'data' => $trxn
            ], RestController::HTTP_OK);
        } else {
            $this->response([
                'status' => FALSE,
                'message' => 'Could not find any transaction '
            ], RestController::HTTP_NOT_FOUND);
        }
    }

    public function index_delete()
    {
        $trxn_id = $this->input->get_post('trxn_id') ? $this->input->get_post('trxn_id') : null;
        $trxn = $this->db
            ->where('transaction_id', $trxn_id)
            ->get($this->table)
            ->row();
        // TODO send only relevant row data into response
        if ($trxn) {

            $this->db->set('is_deleted', 1);
            $this->db->where('transaction_id', $trxn->transaction_id);
            $this->db->where('receipt_number', $trxn->receipt_number);
            $this->db->update($this->table);

            $this->response([
                'status' => TRUE
            ], RestController::HTTP_DELETED);
        } else {
            $this->response([
                'status' => FALSE,
                'message' => 'Could not find any transaction with ' . $trxn_id
            ], RestController::HTTP_NOT_FOUND);
        }
    }

    public function index_put()
    {

        $data = $this->_bind_data();
        $errors = $this->_validate_data($data);

        if ($errors) {
            $this->response([
                'status' => FALSE,
                'message' => $errors,
                'data' => $data,
            ], RestController::HTTP_BAD_REQUEST);
            exit;
        }

        $membership = $this->db
            ->where('membership_number', $data['member_code'])
//            ->where('mobile_number', $data['member_phone'])
            ->get('members')
            ->row();

        //TODO Emergency

        if ($membership) {

            $mobile = $this->_phone_repair($membership->mobile_number);

            if (strpos($mobile, $data['member_phone']) == false) {
                $this->response([
                    'status' => FALSE,
                    'errors' => $errors,
                    'data' => $data,
                    'message' => 'Could not find any membership with phone number ' . $data['member_phone']
                ], RestController::HTTP_NOT_FOUND);
                exit;
            }
        }
//        $membership->mobile_number == $data['member_phone'];

        if (!$membership) {
            $this->response([
                'status' => FALSE,
                'errors' => $errors,
                'data' => $data,
                'message' => 'Could not find any membership ' . $data['member_code']
            ], RestController::HTTP_NOT_FOUND);
            exit;
        }

        $data['member_name'] = $membership->member_name;
        $data['member_address'] = $membership->residential_address;


        $inserted = $this->db->insert($this->table, $data);
        $db_error = $this->db->error();

        if ($inserted) {
            $this->response([
                'status' => TRUE
            ], RestController::HTTP_CREATED);
        } else {
            $this->response([
                'status' => FALSE,
                'data' => $data,
                'message' => 'Could not save the transaction'
            ], RestController::HTTP_INTERNAL_SERVER_ERROR);
            // TODO check and remove duplicate constant for 500 error
        }

//        if (!empty($db_error)) {
//            throw new Exception('Database error code [' . $db_error['code'] . '] msg: ' . $db_error['message']);
//        }
        // TODO Emergency ... try catch not working...!!!! check it
//            try {  }
//            catch (Exception $exception){
//            $this->response([
//                'status' => FALSE,
//                'error'=>$exception->getMessage(),
//                'message' => 'Could not save the transaction'
//            ], RestController::HTTP_INTERNAL_SERVER_ERROR);
//
//            exit;
//            }

    }

    protected function _insert_transaction($data)
    {
        return $this->db->insert($this->table, $data);
    }

    protected function _update_transaction($data)
    {

        return $this->db->update($this->table, $data);
    }

    protected function _delete_transaction($data)
    {

        return $this->db->update($this->table, $data);
    }

    /**
     * @param
     */
    private function _bind_data()
    {

        // TODO remove local variables declaration
        $membership_id = $this->input->get('membership_number') ? $this->input->get('membership_number') : null;
        $association = $this->input->get('association_name') ? $this->input->get('association_name') : null;
        $member_phone = $this->input->get('member_phone') ? $this->_phone_repair($this->input->get('member_phone')) : null;

        $depositor_name = $this->input->get('depositor') ? $this->input->get('depositor') : null;
        $depositor_details = $this->input->get('depositor_details') ? $this->input->get('depositor_details') : null;

        $receipt_number = $this->input->get('receipt') ? $this->input->get('receipt') : null;
        $receipt_type = $this->input->get('receipt_type') ? $this->input->get('receipt_type') : null;
        $bank_entry_number = $this->input->get('entry_number') ? $this->input->get('entry_number') : null;

        // TODO : Set from some settings table DB, retrieve from api_key using $instance_id
        $bank_id = $this->current_bank;

        $branch_id = $this->input->get('branch_code') ? $this->input->get('branch_code') : null;
        $branch_operator_id = $this->input->get('branch_user') ? $this->input->get('branch_user') : null;

        $instance_id = $this->input->request_headers()[$this->config->item('rest_instance_name')];
        $transaction_id = $this->input->get('trxn_id') ? $this->input->get('trxn_id') : null;
        $transaction_amount = $this->input->get('trxn_amount') ? $this->input->get('trxn_amount') : 0;
//        $transaction_date =$this->input->get('trxn_date') ?$this->input->get('trxn_date') : date("Y-m-d H:i:s");

        // TODO check -> form validation trim not working!!!
        $data = [
            'member_code' => trim($membership_id),
            'association_code' => trim($association),
            'member_phone' => trim($member_phone),
            'depositor_name' => trim($depositor_name),
            'depositor_details' => trim($depositor_details),
            'receipt_number' => trim($receipt_number),
            'receipt_type' => trim($receipt_type),
            'bank_code' => trim($bank_id),
            'branch_code' => trim($branch_id),
            'branch_operator_code' => trim($branch_operator_id),
            'bank_entry_number' => trim($bank_entry_number),
            'instance_id' => trim($instance_id),
            'transaction_id' => trim($transaction_id),
            'transaction_amount' => trim($transaction_amount),
//            'transaction_date' => $transaction_date
        ];
        return $data;
    }

    public function receipt_type_check($value)
    {
        $this->form_validation->set_message('receipt_type_check', '{field} must be one of ' . implode(', ', $this->receipt_type));
        return (array_search($value, $this->receipt_type, false));
    }

    public function checkDateTime($dt)
    {
        $pattern = 'same regex pattern';
        if (preg_match($pattern, $this->input->post('fromdatetime'))) {
            return true;
        } else {
            $this->form_validation->set_message('checkDateTime', 'Invalid Date!');
            return false;
        }
    }

    private function _validate_data($data)
    {
        $this->load->library('form_validation');
        $this->form_validation->set_data($data);

        $this->form_validation->set_rules('member_code', 'Membership No.', 'trim|required|min_length[5]');
        $this->form_validation->set_rules('association_code', 'Association', 'trim|required|min_length[4]');
        $this->form_validation->set_rules('depositor_name', 'Depositor', 'trim|required|min_length[3]');
        $this->form_validation->set_rules('depositor_details', 'Depositor Details', 'trim|required|min_length[11]');
        $this->form_validation->set_rules('receipt_number', 'Receipt No.', 'trim|required|min_length[3]');
        $this->form_validation->set_rules('receipt_type', 'Receipt Type', 'trim|callback_receipt_type_check');
        $this->form_validation->set_rules('bank_entry_number', 'Bank Entry No.', 'trim|required|min_length[3]|max_length[10]');
        $this->form_validation->set_rules('branch_code', 'Branch Code', 'trim|required|min_length[3]|max_length[10]');
        $this->form_validation->set_rules('branch_operator_code', 'Bank User', 'trim|required|min_length[3]|max_length[20]');
        $this->form_validation->set_rules('transaction_id', 'Transaction ID', 'trim|required|min_length[3]|max_length[20]');
        $this->form_validation->set_rules('transaction_amount', 'Transaction Amount', 'trim|required|numeric|min_length[3]|max_length[8]');


//        array(
//            'trim','required', 'numeric',
//            'min_length[3]',
//            'max_length[8]',
//            function($value)
//            {
//                return (preg_match('/^[0-9]+(\.[0-9]{1,2})?$/', $value));
//            }));

        //        $this->form_validation->set_rules('transaction_date', 'Transaction Date', 'callback_date_check');

        $this->form_validation->run();
        $errors = $this->form_validation->error_array();
//        print_r($errors);

        return (sizeof($errors) > 0 ? $errors : null);
    }

    public function date_check($date)
    {
        // Empty Transaction Date is acceptable cause db column is default to CURRENT_TIME
        if ($date == null || $date == '') {
            return TRUE;
        }
        // Transaction Date could be a different than CURRENT_TIME

        if ($date && preg_match("/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/", $date)) {
            $this->form_validation->set_message('transaction_date_check', 'The {field} must be formatted as YYYY-mm-dd H:i:s');
            return FALSE;
        }
        return TRUE;
    }

    /**
     * @param array $phone_number
     * @return string|string[]
     */
    protected function _phone_repair($phone_number)
    {
        return str_replace(['-', ' ', '+', '88'], "", $phone_number);
    }

}