<div class="tg-404-error tg-haslayout">
  <main id="tg-main" class="tg-main tg-haslayout">
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div class="tg-404 tg-haslayout">
            <h2>4<span></span>4</h2>
          </div>
          <div class="tg-404-content tg-haslayout">
            <div class="tg-section-heading">
              <h2>The page you’re looking for not found</h2>
            </div>
            <a class="tg-btn" href="<?php echo base_url(); ?>">go to homepage</a>
          </div>
        </div>
      </div>
    </div>
  </main>
</div>