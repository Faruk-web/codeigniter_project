<section class="content">
    <div class="box box-success">
        <div class="box-header with-border">
            <h3 class="box-title"> Details</h3>
        </div>
        <div class="box-body"><?=notFoundText();?></div>
    </div>
</section>